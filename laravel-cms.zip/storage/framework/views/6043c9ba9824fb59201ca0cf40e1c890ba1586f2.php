
<?php $__env->startSection('header'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="card mt-5">
		<div class="card-header">
			<h3 class="card-title">Hello world</h3>
		</div>
		<div class="card-content">
			<div class="card-body">
				<p>
					<?php echo e(__('test.hello_world', ['name' => Auth::user()->name ?? null])); ?>

				</p>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer-assets'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views//pages/home/index.blade.php ENDPATH**/ ?>