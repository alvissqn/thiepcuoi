
<link href="/assets/vendors/bx-icon/style.css" rel="stylesheet" type="text/css">
<script src="/assets/components/vendor.js"></script>
<link href="/assets/plugins/toastr/style.css" rel="stylesheet" type="text/css">
<script src="/assets/plugins/toastr/scripts.js"></script>


<?php if(session()->has('notify')): ?>
    <script>
        toastr.<?php echo e(array_keys( session('notify') )[0]); ?>("<?php echo e(array_values( session('notify') )[0]); ?>", "", {timeOut: 15000, progressBar: !0})
    </script>
<?php endif; ?>


<?php if( Permission::has('admin') && Option::get('settings__admin_quick_edit_language') ): ?>
    <link href="/assets/pages/admin/language-quick-edit/style.css" rel="stylesheet" type="text/css">
    <script src="/assets/pages/admin/language-quick-edit/scripts.js"></script>
<?php endif; ?>


<?php echo \App\Helpers\Assets::show(); ?><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/layouts/includes/footer-assets.blade.php ENDPATH**/ ?>