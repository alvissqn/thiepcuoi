<?php
	use App\Helpers\Form;
?>

<?php $__env->startSection('header'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<main class="row">
		<section class="col-lg-4 mt-2">
			<?php echo $__env->make('pages.admin.account.includes.navbar-menu', ['active' => 'profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</section>
		<section class="col-lg-8 mt-2">
			<div class="card">
				<h4 class="card-header">
					<?php echo e(__('user/profile.account_profile_heading_title')); ?>

				</h4>
				<hr>
				<div class="card-body">
					<section>
						<div class="row-detail row">
							<div style="width: 150px">
								<?php echo e(__('user/profile.account_edit_profile_field_registered_at')); ?>

							</div>
							<div style="width: calc(100% - 150px)">
								<?php echo e(Auth::user()->created_at->format( Option::get('settings__general_date_format') )); ?>

							</div>
						</div>
						<div class="row-detail row">
							<div style="width: 150px">
								<?php echo e(__('user/profile.account_edit_profile_field_name')); ?>

							</div>
							<div style="width: calc(100% - 150px)">
								<?php echo e(Auth::user()->name); ?>

							</div>
						</div>
						<div class="row-detail row">
							<div style="width: 150px">
								<?php echo e(__('user/profile.account_edit_profile_field_phone_number')); ?>

							</div>
							<div style="width: calc(100% - 150px)">
								<?php echo e(Auth::user()->phone_number); ?>

							</div>
						</div>
						<div class="row-detail row">
							<div style="width: 150px">
								<?php echo e(__('user/profile.account_edit_profile_field_email')); ?>

							</div>
							<div style="width: calc(100% - 150px)">
								<?php echo e(Auth::user()->email); ?>

							</div>
						</div>
						<div class="row-detail row">
							<div style="width: 150px">
								<?php echo e(__('user/profile.account_edit_profile_field_gender')); ?>

							</div>
							<div style="width: calc(100% - 150px)">
								<?php echo e(__('user/general.gender_'. config('user.gender.text')[ Auth::user()->gender ] )); ?>

							</div>
						</div>
						<div class="row-detail row">
							<div style="width: 150px">
								<?php echo e(__('user/profile.account_edit_profile_field_birth_day')); ?>

							</div>
							<div style="width: calc(100% - 150px)">
								<?php echo e($userData->birth_day ?? null); ?>

							</div>
						</div>
						<div class="row-detail row">
							<div style="width: 150px">
								<?php echo e(__('user/profile.account_edit_profile_field_job_title')); ?>

							</div>
							<div style="width: calc(100% - 150px)">
								<?php echo e($userData->job_title ?? null); ?>

							</div>
						</div>
						<div class="row-detail row">
							<div style="width: 150px">
								<?php echo e(__('user/profile.account_edit_profile_field_address')); ?>

							</div>
							<div style="width: calc(100% - 150px)">
								<?php echo e($userData->address ?? null); ?>

							</div>
						</div>

					</section>
					<div class="text-center mt-2">
						<a class="btn btn-outline-primary" href="<?php echo e(route('admin.account.edit-profile')); ?>">
							<?php echo e(__('user/profile.update_profile_btn_label')); ?>

						</a>
					</div>
				</div>
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer-assets'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/pages/admin/account/profile.blade.php ENDPATH**/ ?>