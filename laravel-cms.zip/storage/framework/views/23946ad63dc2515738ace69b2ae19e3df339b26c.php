<meta name="language" content="Vietnamese" />
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="shortcut icon" type="image/png" href="" />
<link rel="icon" type="image/png" href="" />



<link href="/assets/components/bootstrap-lite.css" rel="stylesheet" type="text/css">
<link href="/assets/components/style.css" rel="stylesheet" type="text/css">


<script src="/assets/vendors/jquery/jquery.min.js"></script>
<script src="/assets/components/scripts.js"></script>


<?php if( !empty($config['load_js_language']) ): ?>
    <?php echo loadJSLanguage($config['load_js_language']); ?>

<?php endif; ?><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/layouts/includes/header-assets.blade.php ENDPATH**/ ?>