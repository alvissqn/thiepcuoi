
<?php $__env->startSection('header'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
    <link rel="stylesheet" type="text/css" href="/assets/pages/user/authentication.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="row flexbox-container account-form-layout">
	    <div class="col-12 mt-4 mb-4">
	        <div class="card bg-authentication mb-0">
	            <div class="row m-0">
	                <!-- left section-login -->
	                <div class="col-md-6 col-12 px-0">
	                    <div class="card disable-rounded-right mb-0 p-2 h-100 d-flex justify-content-center">
	                        <div class="card-header pb-1">
	                            <div class="card-title">
	                                <h4 class="text-center mb-2">
	                                	<?php echo e(__('user/login.heading_title')); ?>

	                                </h4>
	                            </div>
	                        </div>
	                        <div class="card-content">
	                            <div class="card-body">
	                                <form method="POST" id="user-login-form">
	                                    <?php echo $__env->make('pages.user.includes.login-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	                                </form>
	                                <hr>
	                                <div class="text-center">
	                                	<small class="mr-25">
	                                		<?php echo e(__('user/login.sign_up_tips')); ?>

	                                	</small>
	                                	<a href="register">
	                                		<small>
	                                			<?php echo e(__('user/login.sign_up_label')); ?>

	                                		</small>
	                                	</a>
	                                </div>
	                                <div class="text-center mt-1">
										<a href="/">
											<i class="bx bx-chevron-left"></i>
											<?php echo e(__('user/register.back_to_home')); ?>

										</a>
									</div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <!-- right section image -->
	                <div class="col-md-6 d-md-block d-none text-center align-self-center p-3">
	                    <div class="card-content">
	                        <img class="img-fluid" src="/assets/images/pages/login.png" alt="branding logo">
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer-assets'); ?>
	<script type="text/javascript" src="/assets/pages/user/login.js"></script>
	<script src="/assets/plugins/tooltip/tooltip.min.js"></script>
	<script type="text/javascript">
		$('[data-toggle="tooltip"]').tooltip()
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/pages/user/login.blade.php ENDPATH**/ ?>