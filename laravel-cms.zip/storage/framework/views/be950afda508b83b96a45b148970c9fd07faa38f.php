<?php    
    $configPath = config_path( 'pages/'.str_replace('.', '/', $http_status_code ?? Request::route()->getName() ) ).'.php';
    if( !file_exists($configPath) ){
        putArrayToFile(
            $configPath,
            [
                'title'            => null,
                'description'      => null,
                'background_image' => null,
                'image'            => null,
                'redirect'         => null
            ]
        );
    }
    $config = array_replace(include $configPath, $config);
    if( $config['redirect'] ){
        header('location: '.$config['redirect']); die;
    }
    if( !isset($config['search_engine_index']) ){
        $config['search_engine_index'] = Option::get('settings__general_search_engine_index');
    }
    $config['canonical']   = $config['canonical'] ?? request()->url();
    $config['title']       = cutWords($config['title'], 20);
    $config['description'] = cutWords($config['description'], 35);
?>
<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>" data-textdirection="ltr">
<head>
    <?php $__env->startSection('header'); ?>
        <title><?php echo e($config['title']); ?></title>
        <meta name="description" content="<?php echo $config['description']; ?>" />
        <meta property="og:title" content="<?php echo $config['title']; ?>"/>
        <meta property="og:description" content="<?php echo $config['description']; ?>" />
        <meta property="og:url" content="<?php echo $config['canonical']; ?>">
        <link rel="canonical" href="<?php echo $config['canonical']; ?>" />
        <meta property="og:type" content="article">
        <?php if( !empty($config['image']) ): ?>
            <meta property="og:image" content="<?php echo $config['image']; ?> " />
        <?php endif; ?>
        <?php if( !empty($config['facebook_appID']) ): ?>
            <meta property="fb:app_id" content="<?php echo e($config['facebook_appID']); ?>" />
        <?php endif; ?>
        <meta name="robots" content="<?php echo e($config['search_engine_index'] ? 'index, follow' : 'noindex, nofollow'); ?>" />
        
        <?php echo $__env->make('layouts.includes.header-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('header-tag'); ?>
    <?php echo $__env->yieldSection(); ?>
</head>
<body style="<?php echo empty($config['background_image']) ? '' : 'background: url('.$config['background_image'].') fixed center center no-repeat;
    background-size: cover;'; ?>">
    <!-- Content-->
    <main class="main-layout">
	    <?php echo $__env->yieldContent('content'); ?>
    </main>
    <!-- /Content-->

    <?php $__env->startSection('footer'); ?>
        <footer class="footer text-right pd-20">
            <p>
                Copyright by <a href="/"><?php echo e(request()->getHost()); ?></a>
            </p>
        </footer>
    <?php echo $__env->yieldSection(); ?>


    <?php $__env->startSection('footer-assets'); ?>
        <?php echo $__env->make('layouts.includes.footer-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

</body>

</html><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/layouts/default.blade.php ENDPATH**/ ?>