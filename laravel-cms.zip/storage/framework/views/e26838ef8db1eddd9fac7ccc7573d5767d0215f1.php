<?php
	use App\Helpers\Form;	
?>

<?php $__env->startSection('header'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<main class="row">
		<section class="mt-2 col-md-12">
			<div class="card">
				<div class="card-header row align-items-center">
					<div class="col-md-12">
						<h4 class="card-title">
							<?php echo e(__('admin/page-info.heading_title')); ?>

						</h4>
					</div>
				</div>
				<div class="card-content">
					<form class="card-body pt-0" method="POST" action="<?php echo e(route('admin.settings.page-info.update')); ?>" id="settings-form">
						<div class="accordion collapse-icon accordion-icon-rotate" id="link-item-list">
							<?php $__currentLoopData = glob_recursive( config_path('pages/*.php') ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$getPageConfig = include $file;
									$pageName = str_replace( [config_path('pages/'), '.php', '/'], ['', '', '___'], $file);
								?>
								<div class="card collapse-header">
									<div class="card-header collapsed" data-toggle="collapse" data-target="#item-list-<?php echo e(vnStrFilter($pageName)); ?>">
										<span class="collapse-title">
											<span class="align-middle">
												<?php echo e($getPageConfig['title'] ?? $pageName); ?>

											</span>
										</span>
									</div>
									<div id="item-list-<?php echo e(vnStrFilter($pageName)); ?>" data-parent="#link-item-list"  class="collapse">
										<div class="card-content">
											<div class="card-body">
												<div class="mb-2 position-relative">
													<?php echo Form::text([
															'title'         => '',
															'placeholder'   => '',
															'group_name'    => '',
															'name'          => '',
															'value'         => $pageName,
															'class'         => '',
															'attr'          => 'disabled',
															'icon'          => '',
															'icon_position' => ''
														]); ?>

												</div>
												<div class="mb-2 position-relative">
													<?php echo Form::text([
															'title'         => '',
															'placeholder'   => __('admin/page-info.page_title'),
															'group_name'    => '',
															'name'          => 'data['.$pageName.'][title]',
															'value'         => $getPageConfig['title'],
															'class'         => '',
															'attr'          => '',
															'icon'          => '',
															'icon_position' => ''
														]); ?>

												</div>
												<div class="mb-2 position-relative">
													<?php echo Form::textarea([
															'placeholder'       => '',
															'title' => __('admin/page-info.page_description'),
															'group_name'  => '',
															'name'        => 'data['.$pageName.'][description]',
															'value'       => $getPageConfig['description'],
															'rows'        => 6,
															'class'       => '',
															'attr'        => '',
														]); ?>

												</div>
												<div class="mb-2 position-relative">
													<?php echo Form::text([
															'title'         => '',
															'placeholder'   => __('admin/page-info.page_redirect'),
															'group_name'    => '',
															'name'          => 'data['.$pageName.'][redirect]',
															'value'         => $getPageConfig['redirect'] ?? null,
															'class'         => '',
															'attr'          => '',
															'icon'          => '',
															'icon_position' => ''
														]); ?>

												</div>
											</div><!--/.card-body-->
										</div><!--/.card-content-->
									</div><!--/.collapse-->
								</div><!--/.card-->
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="form-footer-sticky" onclick="settingsSave(this)">
							<button type="button" class="btn btn-primary form-save-btn">
								<i class="bx bx-save"></i>
								<?php echo e(__('admin/language.save_button_label')); ?>

							</button>
						</div>
					</form><!--/.card-body-->
				</div><!--/.card-content-->
			</div><!--/.card-->
		</section>
	</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer-assets'); ?>
	<!-- Page JS-->
	<script src="/assets/pages/admin/settings/scripts.js"></script>
	<!-- /Page JS-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/pages/admin/settings/page-info.blade.php ENDPATH**/ ?>