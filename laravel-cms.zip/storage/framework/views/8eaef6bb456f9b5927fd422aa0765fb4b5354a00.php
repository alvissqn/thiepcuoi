<?php
	$links = [
		'profile' => [
			'label' => __('user/profile.account_profile_heading_title'),
			'icon'  => 'bx-user'
		],
		'change-password' => [
			'label' => __('user/profile.account_change_password_heading_title'),
			'icon'  => 'bx-lock'
		],
		'change-avatar' => [
			'label' => __('user/profile.account_change_avatar_heading_title'),
			'icon'  => 'bx-image'
		],
		'notifications' => [
			'label' => __('user/profile.account_notifications_heading_title'),
			'icon'  => 'bx-bell'
		],
		'logs' => [
			'label' => __('user/profile.account_logs_heading_title'),
			'icon'  => 'bx-history'
		],
	];
?>
<div class="list-group list-group-borderless list-group-box-shadow">
	<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a class="list-group-item list-group-item-action <?php echo e($active == $link ? 'active' : ''); ?>" href="<?php echo e($link); ?>">
			<i class="bx bx-icon mr-50 <?php echo e($item['icon']); ?> align-top"></i>
			<?php echo e($item['label']); ?>

		</a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/pages/admin/account/includes/navbar-menu.blade.php ENDPATH**/ ?>