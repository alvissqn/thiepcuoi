
<?php $__env->startSection('header'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
	<link rel="stylesheet" type="text/css" href="/assets/pages/admin/settings/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<form id="settings-form" action="<?php echo e(route('admin.settings.update')); ?>">
		<?php echo $__env->make('pages.admin.settings.includes.'.$include, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer-assets'); ?>
	<!-- Page JS-->
	<script src="/assets/pages/admin/settings/scripts.js"></script>
	<!-- /Page JS-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/pages/admin/settings/settings-layout.blade.php ENDPATH**/ ?>