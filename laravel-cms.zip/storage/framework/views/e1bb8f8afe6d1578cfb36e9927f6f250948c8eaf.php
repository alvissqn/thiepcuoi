
<?php $__env->startSection('header'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<main class="mt-2">
		<section class="card">
			<h4 class="card-header">
				<?php echo e(__('admin/file_manager.heading_title')); ?>

			</h4>
			<hr>
			<div class="card-body">
				<?php echo $__env->make('includes.file-manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer-assets'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/pages/admin/file-manager.blade.php ENDPATH**/ ?>