
<?php $__env->startSection('header'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
	<link rel="stylesheet" type="text/css" href="/theme/css/pages/dashboard-ecommerce.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	Trang index
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-assets'); ?>
	<?php echo \Illuminate\View\Factory::parentPlaceholder('footer-assets'); ?>
	<!-- Page JS-->
	<script src="/theme/js/scripts/pages/dashboard-ecommerce.js"></script>
	<!-- /Page JS-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/pages/admin/index.blade.php ENDPATH**/ ?>