<?php
	use \App\Services\NotificationServices;
	$splitPath = explode('/', Request::path() );
	$pageParams = [
		'name' => $splitPath[1] ?? null,
		'sname' => $splitPath[2] ?? null,
	];
	if( empty($pageParams['sname']) ){
		$config = config('admin_menu_link')[ $pageParams['name'] ] ?? [];
	}else{
		$config = config('admin_menu_link')[ $pageParams['name'] ]['subs'][ $pageParams['sname'] ] ?? [];
	}
	$config['load_js_language'] = array_merge(
		$config['load_js_language'],
		['general']
	);
	Permission::required($config['permission'], '/');

?>
<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
	<head>
		<?php $__env->startSection('header'); ?>
			<title><?php echo $__env->yieldContent('title', $config['label'] ); ?></title>
			<link href="/assets/pages/admin/main/style.css" rel="stylesheet" type="text/css">
			<?php echo $__env->make('layouts.includes.header-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<script src="/assets/pages/admin/main/scripts.js"></script>
		<?php echo $__env->yieldSection(); ?>
		<?php $__env->startSection('header-tag'); ?>
	    <?php echo $__env->yieldSection(); ?>
	</head>

	<body>
		<div id="loading" class="hide">
			<div>
				<div>
					<i class="bx bx-loader bx-spin bx-flip-vertical text-white font-large-3"></i>
				</div>
			</div>
		</div>
		<main class="admin admin-theme-<?php echo e(Option::get('settings__admin_theme', 'light')); ?>">
			<section class="admin-header row no-gutters align-items-center">
				<div class="admin-header-left">
					<div class="row no-gutters align-items-center">
						<a class="admin-collapse-icon text-center d-lg-none d-xl-none" onclick="adminLeftCollapse()" style="width: 50px">
							<i class="bx bx-menu"></i>
						</a>
						<a class="logo-outer" href="/" style="width: calc(100% - 50px)">
							<img class="logo" src="<?php echo e(Option::get('logo', 'https://trangweb.com/files/uploads/2019/12/Logo-TrangWeb-Small.png')); ?>" alt="Logo">
						</a>
						<a class="admin-collapse-icon text-center d-none d-xl-block d-lg-block" onclick="adminLeftCollapse()" style="width: 50px">
							<i class="bx bx-menu"></i>
						</a>
					</div>
				</div>
				<div class="col-10">
					<div class="row no-gutters align-items-center justify-content-end">
						<div id="header-notifications">
							<a class="link hide" onclick="headerNotification.show(this)">
								<i class="bx bx-bell"></i>
								<sub style="display: none"></sub>
							</a>
							<section class="accordion collapse-icon accordion-icon-rotate collapse-borderless" id="hnotifications-list">
								<div class="p-1 bg-primary text-white row align-items-center no-gutters">
									<div class="col-5 text-ellipsis">
										<?php echo e(__('users/notifications.header_notifications_heading_title')); ?>

									</div>
									<div class="col-7 text-right link text-ellipsis" onclick="headerNotification.maskAsReaded(0); headerNotification.show()">
										<i class="bx bx-check-double"></i>
										<?php echo e(__('users/notifications.header_notifications_heading_mask_as_readed')); ?>

									</div>
								</div>
								<ul class="nav nav-tabs no-gutters">
									<li class="nav-item col-6">
										<a class="nav-link active font-small-3" data-toggle="tab" href="#header-notifications-unread">
											<i class="bx bx-bell align-top"></i>
											<?php echo e(__('users/notifications.header_notifications_heading_unread')); ?> (<span></span>)
										</a>
									</li>
									<li class="nav-item col-6">
										<a class="nav-link font-small-3" data-toggle="tab" href="#header-notifications-readed">
											<i class="bx bx-list-check align-top"></i>
											<?php echo e(__('users/notifications.header_notifications_heading_readed')); ?> (<span></span>)
										</a>
									</li>
								</ul>
								<div class="header-notifications-body custom-scrollbar" style="max-height: 350px; overflow: auto;">
									<div class="tab-content">

										<!-- Chưa đọc -->
										<div class="tab-pane active" id="header-notifications-unread">
								
										</div>
										<!-- /Chưa đọc -->

										<!-- Đã đọc -->
										<div class="tab-pane" id="header-notifications-readed">
										</div>
										<!-- / Đã đọc -->

									</div>
								</div>
								<div class="p-1 text-center bg-white">
									<a href="<?php echo e(route('admin.account.notifications')); ?>">
										<?php echo e(__('users/notifications.header_notifications_see_all')); ?>

									</a>
								</div>
							</section>
						</div>
						<div class="admin-header-user">
							<span style="padding: 10px">
								<span class="avatar">
									<img src="<?php echo \App\Services\UserServices::avatar( Auth::user()->email ); ?>" style="width: 32px; height: 32px">
									<span class="avatar-status-online"></span>
								</span>
								<span class="d-none d-sm-inline-block d-md-inline-block d-lg-inline-block d-xl-inline-block"><?php echo e(Auth::user()->name); ?></span>
								<i class="bx bx-chevron-down"></i>
							</span>
							<nav>
									<a href="<?php echo e(route('admin.account.profile')); ?>">
										<i class="bx bx-user"></i>
										<?php echo e(__('user/general.profile')); ?>

									</a>
									<a href="<?php echo e(route('admin.account.change-password')); ?>">
										<i class="bx bx-lock"></i>
										<?php echo e(__('user/general.change_password')); ?>

									</a>
									<a href="<?php echo e(route('admin.account.change-avatar')); ?>">
										<i class="bx bx-image"></i>
										<?php echo e(__('user/general.change_avatar')); ?>

									</a>
									<a href="<?php echo e(route('admin.account.logs')); ?>">
										<i class="bx bx-history"></i>
										<?php echo e(__('user/general.logs')); ?>

									</a>
									<?php if( request()->cookie('auth_private_key_admin') ): ?>
										<?php
											$adminUserId = explode('.', request()->cookie('auth_private_key_admin') )[0];
										?>
										<a href="<?php echo e(route('user.logout')); ?>">
											<i class="bx bx-log-in"></i>
											<?php echo e(\App\Services\UserServices::get($adminUserId, 'name')); ?>

										</a>
									<?php else: ?>
										<a onclick="return confirm('<?php echo e(__('user/general.logout_confirm')); ?>');" href="<?php echo e(route('user.logout')); ?>">
											<i class="bx bx-log-out"></i>
											<?php echo e(__('user/general.logout')); ?>

										</a>
									<?php endif; ?>
							</nav>
						</div>
					</div>
				</div>
			</section>

			<!--Menu bên trái-->
			<section class="admin-left <?php echo e(( empty($_COOKIE['admin_left_menu_min'] ?? true) ? 'admin-min' : '')); ?>">
				<div class="admin-scrollbar">
					<?php $__currentLoopData = config('admin_menu_link'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if( $item['hidden'] || !Permission::has($item['permission']) ): ?>
							<?php continue; ?>
						<?php endif; ?>
						<?php
							$itemName = $item['label'];
						?>
						
						<?php if( empty($item['subs']) ): ?>
							<a href="<?php echo e(strpos($url, '://') === false ? '/admin/'.$url : $url); ?>" class="<?php echo ( ($pageParams['name'] ?? null) == $url ? 'admin-actived' : ''); ?>">
								<i class="bx <?php echo e($item['icon']); ?>"></i>
								<span>
									<?php echo e($itemName); ?>

									<?php if( ($item['count'] ?? 0) > 0 ): ?>
										<small class="badge badge-pill badge-<?php echo e($item['count_style']); ?> float-right mr-1">
											<?php echo e($item['count']); ?>

										</small>
									<?php endif; ?>
								</span>
							</a>
						<?php else: ?>
							
							<nav class="admin-has-sub admin-arrow-right <?php echo ( ($pageParams['name'] ?? null) == $url ? 'admin-arrow-down' : ''); ?>">
								<i class="bx <?php echo e($item['icon']); ?>"></i>
								<span>
									<?php echo e($itemName); ?>

									<?php if( ($item['count'] ?? 0) > 0 ): ?>
										<small class="badge badge-pill badge-<?php echo e($item['count_style']); ?> float-right mr-1">
											<?php echo e($item['count']); ?>

										</small>
									<?php endif; ?>
								</span>
							</nav>
							<ol style="<?php echo ( ($pageParams['name'] ?? null) == $url ? 'display: block' : ''); ?>">
								<?php $__currentLoopData = $item['subs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surl => $sitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if( $sitem['hidden'] || !Permission::has($sitem['permission']) ): ?>
										<?php continue; ?>
									<?php endif; ?>
									<?php
										$itemName = vnStrFilter($url.'_'.$surl, '_');
										$itemName = __('admin/menu_link.'.$itemName);
									?>
									<li>
										<a href="<?php echo e(strpos($surl, '://') === false ? '/admin/'.$url.'/'.$surl.'' : $surl); ?>" class="<?php echo ( ($pageParams['name'] ?? null) == $url && ($pageParams['sname'] ?? null) == $surl ? 'admin-actived' : ''); ?>">
											<i class="bx bx-right-arrow-alt"></i>
											<span class="menu-item">
												<?php echo e($itemName); ?>

											</span>
											<?php if( ($sitem['count'] ?? 0) > 0 ): ?>
												<span class="badge badge-pill badge-<?php echo e($sitem['count_style']); ?> float-right">
													<?php echo e($sitem['count']); ?>

												</span>
											<?php endif; ?>
										</a>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ol>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<?php if( empty($_COOKIE['admin_left_menu_min'] ?? true) ): ?>
						<div class="admin-collapse d-none d-lg-block d-xl-block" onclick="adminLeftPin()">
							<i class="bx bx-expand"></i>
							<span data-expand="<?php echo e(__('admin/general.menu_expand')); ?>" data-compress="<?php echo e(__('admin/general.menu_compress')); ?>">
								<?php echo e(__('admin/general.menu_expand')); ?>

							</span>
						</div>
					<?php else: ?>
						<div class="admin-collapse d-none d-lg-block d-xl-block" onclick="adminLeftPin()">
							<i class="bx bx-collapse"></i>
							<span data-expand="<?php echo e(__('admin/general.menu_expand')); ?>" data-compress="<?php echo e(__('admin/general.menu_compress')); ?>">
								<?php echo e(__('admin/general.menu_compress')); ?>

							</span>
						</div>
					<?php endif; ?>
					<div class="admin-collapse d-lg-none d-xl-none" onclick="adminLeftCollapse()">
						<i class="bx bx-collapse"></i>
						<span data-expand="<?php echo e(__('admin/general.menu_expand')); ?>" data-compress="<?php echo e(__('admin/general.menu_compress')); ?>">
							<?php echo e(__('admin/general.menu_compress')); ?>

						</span>
					</div>
				</div>
			</section>
			<!--/Menu bên trái-->
	 
			<!--Nội dung bên phải-->
			<section class="admin-right <?php echo e(( empty($_COOKIE['admin_left_menu_min'] ?? true) ? 'admin-min' : '')); ?>">
				<?php echo $__env->yieldContent('content'); ?>
			</section>
			<!--/Nội dung bên phải-->
		</main>
		<div class="clear"></div>
		<?php $__env->startSection('footer'); ?>
			<div class="px-2 py-1 text-right">
				<a class="badge-circle badge-circle-info badge-circle-lg" href="#">
					<i class="bx bx-chevron-up"></i>
				</a>
			</div>
			<footer class="footer footer-static footer-light text-right p-2">
				<p>
					Copyright by <a href="/"><?php echo e(request()->getHost()); ?></a>
				</p>
			</footer>
		<?php echo $__env->yieldSection(); ?>
		
		<?php $__env->startSection('footer-assets'); ?>
			<?php echo $__env->make('layouts.includes.footer-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldSection(); ?>
	</body>
</html><?php /**PATH /home/admin/domains/laravel-cms.azwebsite.vn/public_html/resources/views/layouts/admin.blade.php ENDPATH**/ ?>