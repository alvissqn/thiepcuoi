<?php
return [
	"page_title"            => "Khôi phục lại mật khẩu",
	"page_description"      => "Lấy lại mật khẩu",
	"heading_title"         => "KHÔI PHỤC MẬT KHẨU",
	"heading_description"   => "Quý khách vui lòng nhập mật khẩu mới",
	"submit_label"          => "XÁC NHẬN",
	"private_key_incorrect" => "Mã lấy mật khẩu không hợp lệ, xin thử lại"
];