<?php
return [
	"page_title"       => "Đăng nhập tài khoản",
	"page_description" => "Đăng nhập tài khoản",
	"heading_title"    => "ĐĂNG NHẬP",
	"sign_up_tips"     => "Quý khách chưa có tài khoản?",
	"sign_up_label"    => "Đăng ký",
	"login_with_email" => "hoặc đăng nhập bằng email",
	"keep_session"     => "Giữ đăng nhập",
	"forgot_password"  => "Quên mật khẩu?",
	"submit_label"     => "ĐĂNG NHẬP",
	"login_failed"     => "Thông tin đăng nhập không hợp lệ",
	"login_blocked"    => "Bạn đã đăng nhập sai quá nhiều lần, vui lòng chờ sau :seconds giây"
];