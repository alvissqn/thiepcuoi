<?php
return [
	"page_title"              => "Lấy lại mật khẩu",
	"page_description"        => "Lấy lại mật khẩu",
	"heading_title"           => "LẤY LẠI MẬT KHẨU",
	"heading_description"     => "Quý khách vui lòng điền email để lấy lại mật khẩu",
	"login_with_social"       => "Hoặc đăng nhập bằng",
	"submit_label"            => "XÁC NHẬN",
	"invalid_email_no_exists" => "Email này không tồn tại trên hệ thống",
	"email_sent"              => "Quý khách vui lòng kiểm tra email để đổi mật khẩu",
	"send_mail_failed"        => "Lỗi gửi email, xin vui lòng thử lại hoặc liên hệ chúng tôi để được hỗ trợ",
	"send_mail_subject"       => "Khôi phục mật khẩu: :name"
];