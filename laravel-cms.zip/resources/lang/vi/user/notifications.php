<?php
return array (
  'table_thead_title' => 'user/notifications.table_thead_title',
);