<?php
return array (
  'hello_world' => 'Xin chào bạn :name nha',
  'hello_world_2' => 'test.hello_world_2',
);