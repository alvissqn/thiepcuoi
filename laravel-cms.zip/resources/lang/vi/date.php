<?php
return array (
  'minutes_ago' => 'Phút trước',
  'hours_ago' => 'Giờ trước',
  'yesterday' => 'Hôm qua',
  'days_ago' => 'Ngày trước',
);