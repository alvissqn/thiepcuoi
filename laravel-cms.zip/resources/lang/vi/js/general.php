<?php
return array (
  'update_error_pending_try_again' => 'Lỗi cập nhật, đang thử lại',
  'update_success' => 'Cập nhật thành công',
  'new' => 'Mới',
  'old' => 'Cũ',
);