<?php
return array (
  'forgot_password' => '<div>
			Kính chào: :name 
		</div>
		<div>
			Quý khách đã gửi yêu cầu lấy lại mật khẩu, để khôi phục mật khẩu, xin vui lòng truy cập link bên dưới:
		</div>
		<div style="padding: 10px 0">
			<a target="_blank" href=":link" style="border: 1px solid #00CFDD;background-color: transparent;color: #00CFDD!important; border-radius: 20px; padding: 10px 20px; text-decoration: none;">
				Click để khôi phục mật khẩu
			</a>
		</div>',
  'notification' => ':content',
);