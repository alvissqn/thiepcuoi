<?php
return array (
  'filter_by_user_created' => 'admin/users/notifications.filter_by_user_created',
  'filter_by_user_receiver' => 'admin/users/notifications.filter_by_user_receiver',
);