<?php
return array (
  'please_select_language_path' => 'Vui lòng chọn file ngôn ngữ',
  'please_select_language_package' => 'Vui lòng chọn ngôn ngữ cần chỉnh',
  'update_success' => 'Lưu ngôn ngữ thành công',
  'update_error' => 'Lỗi cập nhật, vui lòng thử lại',
  'language_editor_heading_title' => 'Chỉnh ngôn ngữ',
  'select_language' => 'Ngôn ngữ',
  'select_language_path' => 'File ngôn ngữ',
  'save_button_label' => 'Cập nhật',
);