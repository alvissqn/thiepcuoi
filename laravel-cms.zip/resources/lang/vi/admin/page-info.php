<?php
return array (
  'heading_title' => 'Thiết lập thông tin các trang',
  'page_description' => 'Mô tả trang',
  'page_title' => 'Tiêu đề trang',
  'update_success' => 'Cập nhật thành công',
  'page_public' => 'Cho phép truy cập',
  'page_redirect' => 'Chuyển hướng đến link khác',
);