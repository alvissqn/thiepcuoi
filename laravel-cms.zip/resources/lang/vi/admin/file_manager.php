<?php
return array (
  'heading_title' => 'Quản lý tệp tin',
  'search_label' => 'Tìm tên tệp tin',
  'filter_by_file_type' => 'Loại tệp tin',
);