<?php
return array (
  'option_title' => 'Thiết lập chung',
  'language' => 'Ngôn ngữ',
  'search_engine_index' => 'Cho phép công cụ tìm kiếm lập chỉ mục',
  'pagination_limit' => 'Số lượng phân trang',
  'date_format' => 'Định dạng ngày',
  'time_format' => 'Định dạng ngày giờ',
);