<?php
return array (
  'heading_title' => 'Lịch sử thao tác',
  'table_thead_user_name' => 'Tài khoản',
  'table_thead_category' => 'Phân loại',
  'table_thead_action' => 'Thao tác',
  'table_thead_time' => 'Thời gian',
  'table_thead_detail' => 'Chi tiết',
  'action_history_title' => 'Lịch sử thao tác',
  'see_all_logs' => 'Xem tất cả',
  'action_title_' => 'admin/tools/logs.action_title_',
  'find_by_user' => 'Tìm người thao tác',
);