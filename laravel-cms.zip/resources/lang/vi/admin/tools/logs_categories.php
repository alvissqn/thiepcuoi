<?php
return array (
  'permission' => 'Phân quyền',
  'language' => 'Ngôn ngữ',
  'account' => 'Tài khoản',
  'settings' => 'Cài đặt',
  'pages_info' => 'Thông tin trang',
  0 => 'admin/tools/logs_categories.',
  'user_manager' => 'Quản lý tài khoản',
  'notification' => 'Thông báo',
);