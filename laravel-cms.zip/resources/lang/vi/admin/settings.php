<?php
return array (
  'language_editor_heading_title' => 'admin/settings.language_editor_heading_title',
  'general_option_title' => 'Thiết lập chung',
  'general_option_language' => 'Ngôn ngữ',
  'search_engine_index' => 'admin/settings.search_engine_index',
  'save_button_label' => 'Lưu lại',
);