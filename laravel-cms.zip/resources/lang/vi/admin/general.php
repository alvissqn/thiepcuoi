<?php
return array (
  'search_no_result' => 'Không tìm thấy kết quả',
  'search_in_menu' => 'Tìm trong menu',
  'your_account_is_incompetence' => 'Tài khoản của bạn không có quyền truy cập trang này',
  'menu_compress' => 'Thu gọn menu',
  'menu_expand' => 'Cố định menu',
);