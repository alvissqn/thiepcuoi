<?php
return array (
  'role_heading_title' => 'Chức vụ',
  'permission_heading_title' => 'Danh sách các quyền',
  'permission_save_btn_label' => 'Cập nhật tên quyền',
  'update_role' => 'Cập nhật chức vụ',
  'input_role_name' => 'Tên chức vụ',
  'input_role_color' => 'Màu nick',
  'update_role_btn_label' => 'Cập nhật',
  'set_permission_title' => 'Thiết lập quyền cho chức vụ',
  'add_new_role' => 'Thêm chức vụ mới',
  'set_permission_for_' => 'Thiết lập quyền cho: :role_name',
  'data_is_incorrect' => 'Dữ liệu không hợp lệ',
  'delete_role_' => 'Xóa chức vụ: :role_name',
  'delete_role_btn_label' => 'Xác nhận xóa',
  'delete_role_move_to' => 'Chuyển thành viên hiện tại sang',
);