@extends('layouts.admin')
@section('header')
	@parent
	<link rel="stylesheet" type="text/css" href="/theme/css/pages/dashboard-ecommerce.css">
@endsection

@section('content')
	Trang index
@endsection

@section('footer')
	@parent
@endsection

@section('footer-assets')
	@parent
	<!-- Page JS-->
	<script src="/theme/js/scripts/pages/dashboard-ecommerce.js"></script>
	<!-- /Page JS-->
@endsection