<div style="font-family:\'Segoe UI\',Arial,sans-serif;font-size:16px;background:#eaeaea; padding: 50px 10px" bgcolor="#eaeaea">
	<table cellspacing="0" align="center" style="width: 100%; max-width:700px;border-radius:2px;border-spacing:0px;margin-left:auto;margin-right:auto;background:#fff;border:1px solid #dddddd" bgcolor="#FFF">
		<tr>
			<td style="padding: 15px; text-align: center; background-color: blue">
				<img src="https://trangweb.com/files/uploads/2019/12/Logo-TrangWeb-Small.png" style="max-width: 100%; max-height: 80px">
			</td>
		</tr>
		<tr>
			<td style="text-align:left;color:#666;font-size:15px;line-height:26px;padding:25px">
				@yield('body')
			</td>
		</tr>
		<tr>
			<td style="text-align:left;color:#666;font-size:15px;line-height:26px;padding: 0 25px 25px 25px">
				Nội dung dưới chân email
			</td>
		</tr>
	</table>
</div>