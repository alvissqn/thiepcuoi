<?php
namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Services\UserServices;
use App\Services\UserDataServices;
use Auth, Permission;

class ProfileController extends Controller{

	

}