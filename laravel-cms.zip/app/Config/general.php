<?php

return [
	// Số lượng/trang
	'pagination_limit' => [
		50   => 50,
		100  => 100,
		500  => 500,
		1000 => 1000
	],

	// Xóa các bản lịch sử thao tác sau số tháng
	'logs_cleanup_months' => 1,

];