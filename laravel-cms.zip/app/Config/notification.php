<?php

return [
	// Các chuyên mục thông báo
	'type' => [
		'code' => [
			'message' => 0,
			'notify'  => 1
		],
		'text' =>[
			0 => 'message',
			1 => 'notify'
		]
	],

	// Tự động xóa thông báo sau (tháng)
	'auto_cleanup' => 3,
];