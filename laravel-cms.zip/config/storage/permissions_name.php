<?php
return array (
  'post' => 'Đăng bài',
  'user_manager' => 'Quản lý người dùng',
  'file_manager' => 'File_manager',
);