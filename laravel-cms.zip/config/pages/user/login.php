<?php
return array (
  'title' => 'Đăng nhập',
  'description' => NULL,
  'redirect' => NULL,
);