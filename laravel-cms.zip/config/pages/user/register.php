<?php
return array (
  'title' => 'Đăng ký',
  'description' => NULL,
  'redirect' => NULL,
);