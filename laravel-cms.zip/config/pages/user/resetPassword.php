<?php
return array (
  'title' => NULL,
  'description' => NULL,
  'background_image' => NULL,
  'image' => NULL,
  'redirect' => NULL,
);