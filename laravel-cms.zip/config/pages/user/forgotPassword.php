<?php
return array (
  'title' => 'Quên mật khẩu',
  'description' => NULL,
  'redirect' => NULL,
);