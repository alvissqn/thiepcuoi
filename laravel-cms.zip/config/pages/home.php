<?php
return array (
  'title' => 'Trang chủ',
  'description' => 'Đây là mmmmmttt',
  'redirect' => NULL,
);